from DatabaseHandler import Database
from DatabaseHandler.models import User

USER = "postgres"
HOST = "127.0.0.1"
PASSWORD = "postgres"
DATABASE_NAME = "fakhrbank"
PORT = "5432"

db = Database(HOST, PORT, DATABASE_NAME, USER, PASSWORD)
# if db.check_connection():
#     res = db.select('Avocado', ['"Date"', '"type"', '"year"'], filters='"year" > 2015')
#     print(res)
#     res = db.insert('loan_records', ['borrower', 'bank_manager', 'loan_amount'], [('mohsen', 'ali', '2095'), ('aaa', 'bbb', '33333')])
#     print(res)
#     res = db.delete('loan_records', "borrower like '%a'")
#     print(res)
#     res = db.update('loan_records', {"loan_amount":2250000}, "borrower = 'mohsen'")
#     print(res)
#     res = db.create_table('testi', {'id': 'serial primary key', 'name': 'text'})
#     print(res)

res = db.select('Users', Model=User)
print(res)



