from psycopg2 import sql, connect

USER = "postgres"
HOST = "127.0.0.1"
PASSWORD = "postgres"
DATABASE_NAME = "fakhrbank"
PORT = "5432"

conn = connect(host=HOST, port=PORT, user=USER, password=PASSWORD, dbname=DATABASE_NAME)
cursor = conn.cursor()
a = "' or 1 = 1 --"
command = "INSERT INTO Loans (profit, deadline, atleastincome, status) VALUES (?, ?, ?, ?)"
cursor.execute(command, (20, 5, 123, True))
res = cursor.fetchall()
print(res)
conn.close()
cursor.close()
